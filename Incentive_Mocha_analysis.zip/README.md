# Federated MOCHA Analysis

This repository contains Python scripts for analyzing and visualizing the performance of **FedAvg** vs **MOCHA (Multi-Task Learning)** under different scenarios.

## Contents
- `iterations_vs_owners.py` → Convergence comparison (iterations vs number of data owners).
- `delay_scaling.py` → Delay scaling with number of workers.
- `mocha_analysis_10tasks.py` → MOCHA analysis with 10 tasks.
- `mocha_equilibrium_3d.py` → 3D equilibrium visualization of MOCHA.
- `worker_analysis.py` → Worker-based performance comparison.
- `performance_heatmap.py` → Heatmap of system performance.
- `code6.py` → Custom visualization script 1.
- `code7.py` → Custom visualization script 2.

## Usage
```bash
pip install -r requirements.txt
python iterations_vs_owners.py
```
Each script generates plots for comparative analysis.

## Requirements
- Python 3.x
- NumPy
- Matplotlib
- SciPy
